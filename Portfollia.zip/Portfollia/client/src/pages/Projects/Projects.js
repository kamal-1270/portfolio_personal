import React from 'react'
import './Projects.css'
import imag from '../../images/download.jpeg'
import weatherimg from '../../images/weather.jpg'
const Projects = () => {
  return (
    <>
    <div className='container project' id='projects'>
    <h2 className='col-12 mt-3 mb-1 text-center text-uppercase'>
        Top Recent Projects</h2>
      <hr/>
      <p className='pb-3 text-center'>👉 Here are my top 3 Projects with live links and source code</p>
        <div className='row' id='ads'>
            {/* project 1 */}
    <div className='col-md-4'>
        <div className='card rounded'>
            <div className='card-image'>
                <span className='card-notify-badge'>Full Stack</span>
                <img src={imag} alt='project1'/>
            </div>
            <div className='card-image-overly m-auto mt-3'>
                <span className='card-detail-badge'>Node</span>
                <span className='card-detail-badge'>Express</span>
                <span className='card-detail-badge'>React</span>
                <span className='card-detail-badge'>MongoDB</span>
            </div>
            <div className='card-body text-center'>
                <div className='ad-title m-auto'>
                    <h5 className='text-uppercase'>
                    ApnaTrip Travelling Website
                    </h5>
                </div>
                <a className='ad-btn' href='#'>view</a>
            </div>
        </div>
    </div>
    {/* project 2 */}
    <div className='col-md-4'>
        <div className='card rounded'>
            <div className='card-image'>
                <span className='card-notify-badge'>Mobile App</span>
                <img src={weatherimg} alt='project1'/>
            </div>
            <div className='card-image-overly m-auto mt-3'>
                <span className='card-detail-badge'>React Native</span>
                <span className='card-detail-badge'>IOS / ANDROID</span>
            </div>
            <div className='card-body text-center'>
                <div className='ad-title m-auto'>
                    <h5 className='text-uppercase'>
                    Weather App
                    </h5>
                </div>
                <a className='ad-btn' href='#'>view</a>
            </div>
        </div>
    </div>
    {/* project 3 */}
    <div className='col-md-4'>
        <div className='card rounded'>
            <div className='card-image'>
                <span className='card-notify-badge'>Full Stack</span>
                <img src={imag} alt='project1'/>
            </div>
            <div className='card-image-overly m-auto mt-3'>
                <span className='card-detail-badge'>Node</span>
                <span className='card-detail-badge'>Express</span>
                <span className='card-detail-badge'>React</span>
                <span className='card-detail-badge'>MongoDB</span>
            </div>
            <div className='card-body text-center'>
                <div className='ad-title m-auto'>
                    <h5 className='text-uppercase'>
                    ApnaTrip Travelling Website
                    </h5>
                </div>
                <a className='ad-btn' href='#'>view</a>
            </div>
        </div>
    </div>
        </div>
    </div>
    </>
  )
}

export default Projects
